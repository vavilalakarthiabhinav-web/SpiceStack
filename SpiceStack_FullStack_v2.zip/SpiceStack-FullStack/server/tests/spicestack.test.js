const test = require('node:test');
const assert = require('node:assert/strict');
const {
  getMaxPrepTime,
  computeTargetPrepStart,
  isTableLocked,
  calcOrderTotals,
  rankKdsTickets,
  validateBookingPayload
} = require('../src/utils/kdsEngine');
const { TABLES_SEED, TIME_SLOTS, MENU_SEED } = require('../src/data/seed');

test('Arrival-Synchronized Firing Heuristic computes exact TargetPrepStart', () => {
  const items = [
    { id: 'M07', prepTime: 20, price: 480, qty: 2 }, // Biryani 20m
    { id: 'M19', prepTime: 10, price: 95, qty: 2 }   // Naan 10m
  ];
  assert.equal(getMaxPrepTime(items), 20);
  // 8:00 PM (1200 mins) - 20 mins = 7:40 PM (1180 mins)
  assert.equal(computeTargetPrepStart(1200, items), 1180);
});

test('Atomic 90-Minute Slot Lock prevents overlapping bookings on same table', () => {
  const existing = [
    { id: 'SPK-1', tableId: 'T4', date: '2026-11-25', arrivalMins: 1200 } // 8:00 PM
  ];
  // Same table at 8:00 PM -> locked
  assert.equal(isTableLocked(existing, 'T4', '2026-11-25', 1200), true);
  // Same table at 7:30 PM (30m diff < 90m) -> locked
  assert.equal(isTableLocked(existing, 'T4', '2026-11-25', 1170), true);
  // Same table at 9:30 PM (90m diff) -> unlocked
  assert.equal(isTableLocked(existing, 'T4', '2026-11-25', 1290), false);
  // Different table at 8:00 PM -> unlocked
  assert.equal(isTableLocked(existing, 'T3', '2026-11-25', 1200), false);
});

test('KDS Priority Queue promotes Checked-In and Fire-Now tickets to top', () => {
  const reservations = [
    {
      id: 'FUTURE',
      arrivalMins: 1260, // 9:00 PM
      kdsStatus: 'Pending',
      checkedIn: false,
      items: [{ prepTime: 15 }]
    },
    {
      id: 'FIRE_NOW',
      arrivalMins: 1200, // 8:00 PM -> fires at 7:40 PM (1180)
      kdsStatus: 'Pending',
      checkedIn: false,
      items: [{ prepTime: 20 }]
    },
    {
      id: 'EARLY_CHECKIN',
      arrivalMins: 1260,
      kdsStatus: 'Pending',
      checkedIn: true,
      items: [{ prepTime: 15 }]
    }
  ];

  const ranked = rankKdsTickets(reservations, 1180); // 7:40 PM
  assert.equal(ranked[0].id, 'EARLY_CHECKIN');
  assert.equal(ranked[1].id, 'FIRE_NOW');
  assert.equal(ranked[1].shouldFireNow, true);
  assert.equal(ranked[2].id, 'FUTURE');
  assert.equal(ranked[2].shouldFireNow, false);
});

test('Automated Billing computes 5% GST, 10% Service Charge, and per-guest split', () => {
  const items = [
    { price: 500, qty: 2 }, // 1000
    { price: 200, qty: 1 }  // 200 -> subtotal 1200
  ];
  const totals = calcOrderTotals(items, 4);
  assert.equal(totals.subtotal, 1200);
  assert.equal(totals.gst, 60);
  assert.equal(totals.serviceCharge, 120);
  assert.equal(totals.total, 1380);
  assert.equal(totals.perGuest, 345);
});

test('Server-Side Payload Validation rejects invalid phone, oversized party, or empty cart', () => {
  const badPayload = {
    guestName: 'A',
    phone: '123',
    partySize: 6,
    date: '2026-11-25',
    slotId: '20:00',
    tableId: 'T1', // capacity 2 < partySize 6
    items: []
  };
  const errors = validateBookingPayload(badPayload, TABLES_SEED, TIME_SLOTS, MENU_SEED);
  assert.ok(errors.length >= 4);
});
