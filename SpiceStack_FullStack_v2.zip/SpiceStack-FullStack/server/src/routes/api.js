const express = require('express');
const router = express.Router();
const { TABLES_SEED, TIME_SLOTS, MENU_SEED, getInitialReservations } = require('../data/seed');
const { loadReservations, saveReservations } = require('../utils/store');
const {
  isTableLocked,
  validateBookingPayload,
  rankKdsTickets,
  calcOrderTotals
} = require('../utils/kdsEngine');

let reservations = loadReservations();

// GET /api/bootstrap - Fetch tables, slots, menu, and active reservations
router.get('/bootstrap', (req, res) => {
  res.json({
    tables: TABLES_SEED,
    slots: TIME_SLOTS,
    menu: MENU_SEED,
    reservations
  });
});

// GET /api/kds?clockMins=1180 - Ranked KDS tickets for current simulated/real time
router.get('/kds', (req, res) => {
  const clockMins = Number(req.query.clockMins) || (19 * 60 + 35);
  const tickets = rankKdsTickets(reservations, clockMins);
  res.json({ tickets });
});

// POST /api/reservations - Validate & create reservation with atomic 90-min slot lock
router.post('/reservations', (req, res) => {
  const errors = validateBookingPayload(req.body, TABLES_SEED, TIME_SLOTS, MENU_SEED);
  if (errors.length > 0) {
    return res.status(400).json({ error: 'Validation failed', details: errors });
  }

  const { guestName, phone, partySize, date, slotId, tableId, items, allergyNotes } = req.body;
  const slot = TIME_SLOTS.find(s => s.id === slotId);

  if (isTableLocked(reservations, tableId, date, slot.startMins)) {
    return res.status(409).json({
      error: 'SlotConflict',
      message: 'Atomic Lock Triggered: Table is already booked within a 90-minute window.'
    });
  }

  // Hydrate canonical menu prices/prepTimes from server catalog (prevents client price tampering)
  const hydratedItems = items.map(i => {
    const canonical = MENU_SEED.find(m => m.id === i.id);
    return { ...canonical, qty: Number(i.qty) };
  });

  const newRes = {
    id: 'SPK-' + Math.floor(1000 + Math.random() * 9000),
    guestName: guestName.trim(),
    phone: phone.trim(),
    partySize: Number(partySize),
    date,
    slotId,
    slotLabel: slot.label,
    arrivalMins: slot.startMins,
    tableId,
    items: hydratedItems,
    allergyNotes: (allergyNotes || '').trim().slice(0, 200) || 'None',
    kdsStatus: 'Pending',
    checkedIn: false,
    courseStage: 'Reserved',
    splitCount: Number(partySize),
    createdAt: Date.now()
  };

  reservations = [newRes, ...reservations];
  saveReservations(reservations);

  return res.status(201).json({
    reservation: newRes,
    billing: calcOrderTotals(hydratedItems, newRes.partySize)
  });
});

// PATCH /api/reservations/:id/kds - Update kitchen ticket status
router.patch('/reservations/:id/kds', (req, res) => {
  const { status } = req.body;
  if (!['Pending', 'Cooking', 'Plated'].includes(status)) {
    return res.status(400).json({ error: 'Invalid KDS status' });
  }
  const idx = reservations.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Reservation not found' });

  reservations[idx] = { ...reservations[idx], kdsStatus: status };
  saveReservations(reservations);
  res.json({ reservation: reservations[idx] });
});

// PATCH /api/reservations/:id/checkin - Hostess check-in & early arrival KDS promotion
router.patch('/reservations/:id/checkin', (req, res) => {
  const idx = reservations.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Reservation not found' });

  reservations[idx] = {
    ...reservations[idx],
    checkedIn: true,
    courseStage: 'Seated'
  };
  saveReservations(reservations);
  res.json({ reservation: reservations[idx] });
});

// PATCH /api/reservations/:id/course - Advance table course stage
router.patch('/reservations/:id/course', (req, res) => {
  const stages = ['Reserved', 'Seated', 'Mains Served', 'Dessert/Check'];
  const idx = reservations.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Reservation not found' });

  const nextIdx = (stages.indexOf(reservations[idx].courseStage) + 1) % stages.length;
  reservations[idx] = {
    ...reservations[idx],
    courseStage: stages[nextIdx],
    checkedIn: nextIdx > 0
  };
  saveReservations(reservations);
  res.json({ reservation: reservations[idx] });
});

// POST /api/demo/reset - Reset demo scenario
router.post('/demo/reset', (req, res) => {
  const todayStr = new Date().toISOString().split('T')[0];
  reservations = getInitialReservations(todayStr);
  saveReservations(reservations);
  res.json({ reservations });
});

module.exports = router;
