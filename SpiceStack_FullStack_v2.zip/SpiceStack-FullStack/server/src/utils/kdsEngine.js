/**
 * Pure domain logic for SpiceStack KDS synchronization, atomic slot locking,
 * and automated tax/split billing.
 */

function getMaxPrepTime(items) {
  if (!Array.isArray(items) || items.length === 0) return 15;
  return Math.max(...items.map(i => Number(i.prepTime) || 10));
}

function computeTargetPrepStart(arrivalMins, items) {
  const maxPrep = getMaxPrepTime(items);
  return arrivalMins - maxPrep;
}

function isTableLocked(reservations, tableId, date, targetStartMins, windowMins = 90) {
  return reservations.some(r => {
    if (r.tableId !== tableId || r.date !== date) return false;
    return Math.abs(r.arrivalMins - targetStartMins) < windowMins;
  });
}

function calcOrderTotals(items, partySize = 1) {
  const subtotal = items.reduce((sum, i) => sum + (Number(i.price) * Number(i.qty)), 0);
  const gst = Math.round(subtotal * 0.05);
  const serviceCharge = Math.round(subtotal * 0.10);
  const total = subtotal + gst + serviceCharge;
  const perGuest = partySize > 0 ? Math.ceil(total / partySize) : total;
  return { subtotal, gst, serviceCharge, total, perGuest };
}

function rankKdsTickets(reservations, simClockMins) {
  return [...reservations].map(res => {
    const maxPrep = getMaxPrepTime(res.items);
    const targetPrepStart = computeTargetPrepStart(res.arrivalMins, res.items);
    const minsUntilArrival = res.arrivalMins - simClockMins;
    const minsUntilFire = targetPrepStart - simClockMins;
    const shouldFireNow =
      (minsUntilFire <= 0 && res.kdsStatus === 'Pending') ||
      (res.checkedIn && res.kdsStatus === 'Pending');

    return {
      ...res,
      maxPrep,
      targetPrepStart,
      minsUntilArrival,
      minsUntilFire,
      shouldFireNow
    };
  }).sort((a, b) => {
    const rank = (t) => {
      if (t.kdsStatus === 'Plated') return 4;
      if (t.checkedIn && t.kdsStatus === 'Pending') return 0;
      if (t.shouldFireNow) return 1;
      if (t.kdsStatus === 'Cooking') return 2;
      return 3;
    };
    if (rank(a) !== rank(b)) return rank(a) - rank(b);
    return a.targetPrepStart - b.targetPrepStart;
  });
}

function validateBookingPayload(payload, tables, slots, menu) {
  const errors = [];
  if (!payload || typeof payload !== 'object') {
    return ['Invalid JSON request body'];
  }
  const { guestName, phone, partySize, date, slotId, tableId, items } = payload;

  if (!guestName || typeof guestName !== 'string' || guestName.trim().length < 2) {
    errors.push('Guest name must be at least 2 characters.');
  }
  const cleanPhone = String(phone || '').replace(/\s+/g, '');
  if (!/^\+?[0-9]{10,15}$/.test(cleanPhone)) {
    errors.push('Valid 10-15 digit phone number is required.');
  }
  const size = Number(partySize);
  if (!Number.isInteger(size) || size < 1 || size > 12) {
    errors.push('Party size must be between 1 and 12 guests.');
  }
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    errors.push('Date must be in YYYY-MM-DD format.');
  }
  const slot = slots.find(s => s.id === slotId);
  if (!slot) {
    errors.push('Selected time slot does not exist.');
  }
  const table = tables.find(t => t.id === tableId);
  if (!table) {
    errors.push('Selected table does not exist.');
  } else if (table.capacity < size) {
    errors.push(`Table ${table.name} capacity (${table.capacity}) is smaller than party size (${size}).`);
  }
  if (!Array.isArray(items) || items.length === 0) {
    errors.push('At least one valid menu dish must be pre-ordered.');
  } else {
    for (const item of items) {
      const menuItem = menu.find(m => m.id === item.id);
      if (!menuItem || !Number.isInteger(item.qty) || item.qty < 1 || item.qty > 20) {
        errors.push(`Invalid menu item or quantity for ${item.id || 'unknown'}.`);
      }
    }
  }
  return errors;
}

module.exports = {
  getMaxPrepTime,
  computeTargetPrepStart,
  isTableLocked,
  calcOrderTotals,
  rankKdsTickets,
  validateBookingPayload
};
