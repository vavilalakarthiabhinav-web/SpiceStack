const fs = require('fs');
const path = require('path');
const { getInitialReservations } = require('../data/seed');

const DB_PATH = path.join(__dirname, '../../data_store.json');

function loadReservations() {
  const todayStr = new Date().toISOString().split('T')[0];
  try {
    if (!fs.existsSync(DB_PATH)) {
      const seed = getInitialReservations(todayStr);
      saveReservations(seed);
      return seed;
    }
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('[Store] Failed to load DB, falling back to seed:', err.message);
    return getInitialReservations(todayStr);
  }
}

function saveReservations(data) {
  const tmpPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, DB_PATH);
}

module.exports = { loadReservations, saveReservations };
