const express = require('express');
const cors = require('cors');
const apiRouter = require('./routes/api');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'spicestack-api' }));
app.use('/api', apiRouter);

// Global Express Error Handler
app.use((err, req, res, next) => {
  console.error('[API Error]', err);
  res.status(500).json({ error: 'InternalServerError', message: err.message });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`SpiceStack API running on http://localhost:${PORT}`);
  });
}

module.exports = app;
