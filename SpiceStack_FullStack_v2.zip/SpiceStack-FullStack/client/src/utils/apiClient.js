const API_BASE = 'http://localhost:4000/api';

export async function apiRequest(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json();
  if (!response.ok) {
    const msg = data.details ? data.details.join(' ') : (data.message || data.error || 'Request failed');
    throw new Error(msg);
  }
  return data;
}
