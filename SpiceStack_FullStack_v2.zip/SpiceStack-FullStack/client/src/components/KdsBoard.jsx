import React from 'react';

export default function KdsBoard({ tickets, tables, formatMinsToTime, onUpdateStatus }) {
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-amber-400">Arrival-Synchronized KDS</span>
          <h2 className="text-3xl font-extrabold tracking-tight mt-0.5">Live Kitchen Order Queue</h2>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs font-bold">
          <span className="px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40">● Yellow: Pending</span>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">● Green: Cooking</span>
          <span className="px-3 py-1.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/40">● Blue: Plated</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {tickets.map(ticket => {
          const statusColor =
            ticket.kdsStatus === 'Pending' ? 'bg-amber-400 text-stone-950' :
            ticket.kdsStatus === 'Cooking' ? 'bg-emerald-500 text-stone-950' :
            'bg-blue-500 text-white';

          return (
            <div
              key={ticket.id}
              className={`rounded-2xl bg-[#111827] border-2 p-5 flex flex-col justify-between transition ${
                ticket.shouldFireNow
                  ? 'border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.35)]'
                  : ticket.kdsStatus === 'Cooking'
                    ? 'border-emerald-500/70'
                    : ticket.kdsStatus === 'Plated'
                      ? 'border-blue-500/50 opacity-75'
                      : 'border-slate-700'
              }`}
            >
              <div>
                {ticket.shouldFireNow && (
                  <div className="mb-4 px-3 py-2 rounded-xl bg-amber-400 text-stone-950 font-extrabold text-sm">
                    <i className="fa-solid fa-fire mr-1.5"></i>
                    {ticket.checkedIn ? 'PRIORITY: GUEST CHECKED IN!' : `FIRE DISH NOW — Arrives in ${Math.max(0, ticket.minsUntilArrival)}m`}
                  </div>
                )}

                <div className="flex items-start justify-between gap-2 pb-4 border-b border-slate-800">
                  <div>
                    <h3 className="text-3xl font-extrabold tracking-tight text-white">
                      {tables.find(t => t.id === ticket.tableId)?.name || ticket.tableId}
                    </h3>
                    <p className="text-sm text-slate-400 font-semibold mt-0.5">{ticket.guestName} • {ticket.id}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-lg text-xs font-extrabold uppercase tracking-wider ${statusColor}`}>
                    {ticket.kdsStatus}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 my-4 text-center bg-slate-900/90 rounded-xl p-3 border border-slate-800">
                  <div>
                    <p className="text-[10px] uppercase text-slate-400 font-bold">Arrival</p>
                    <p className="font-mono text-sm font-bold text-white">{formatMinsToTime(ticket.arrivalMins)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-slate-400 font-bold">Target Fire</p>
                    <p className="font-mono text-sm font-bold text-amber-400">{formatMinsToTime(ticket.targetPrepStart)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase text-slate-400 font-bold">Max Prep</p>
                    <p className="font-mono text-sm font-bold text-emerald-400">{ticket.maxPrep} min</p>
                  </div>
                </div>

                <ul className="space-y-2 mb-4">
                  {ticket.items.map(item => (
                    <li key={item.id} className="flex items-center justify-between text-base font-bold text-slate-100 bg-slate-800/60 px-3 py-2 rounded-lg">
                      <span>{item.qty}× {item.name}</span>
                      <span className="font-mono text-xs text-slate-400">{item.prepTime}m</span>
                    </li>
                  ))}
                </ul>

                {ticket.allergyNotes && ticket.allergyNotes !== 'None' && (
                  <div className="mb-4 px-3 py-2 rounded-lg bg-red-500/20 border border-red-500/40 text-red-200 text-xs font-bold">
                    <i className="fa-solid fa-triangle-exclamation mr-1.5"></i> NOTE: {ticket.allergyNotes}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-800">
                <button
                  onClick={() => onUpdateStatus(ticket.id, 'Cooking')}
                  disabled={ticket.kdsStatus !== 'Pending'}
                  className={`py-3 rounded-xl font-extrabold text-sm transition ${
                    ticket.kdsStatus === 'Pending'
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-stone-950'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Start Cooking
                </button>
                <button
                  onClick={() => onUpdateStatus(ticket.id, 'Plated')}
                  disabled={ticket.kdsStatus === 'Plated'}
                  className={`py-3 rounded-xl font-extrabold text-sm transition ${
                    ticket.kdsStatus !== 'Plated'
                      ? 'bg-blue-500 hover:bg-blue-400 text-white'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Ready / Plated
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </main>
  );
}
