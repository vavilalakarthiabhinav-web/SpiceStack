import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorMessage: error?.message || 'Unexpected UI error' };
  }

  componentDidCatch(error, info) {
    console.error('[SpiceStack ErrorBoundary]', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#FAF8F5] p-6">
          <div className="max-w-md w-full bg-white rounded-2xl p-6 border border-red-200 shadow-sm space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 mx-auto flex items-center justify-center text-xl">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h2 className="text-xl font-bold text-stone-900">Interface Recovery Triggered</h2>
            <p className="text-sm text-stone-600">{this.state.errorMessage}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2.5 rounded-xl bg-[#C2410C] text-white text-sm font-bold"
            >
              Reload SpiceStack
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
