import React, { useState, useEffect, useMemo } from 'react';
import { apiRequest } from './utils/apiClient';
import KdsBoard from './components/KdsBoard';

const formatMinsToTime = (totalMins) => {
  const h24 = Math.floor(totalMins / 60) % 24;
  const m = totalMins % 60;
  const period = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${m.toString().padStart(2, '0')} ${period}`;
};

export default function App() {
  const [activeTab, setActiveTab] = useState('diner');
  const [tables, setTables] = useState([]);
  const [slots, setSlots] = useState([]);
  const [menu, setMenu] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [simClockMins, setSimClockMins] = useState(19 * 60 + 35);
  const [toast, setToast] = useState(null);
  const [backendOnline, setBackendOnline] = useState(true);

  // Booking form state
  const [guestName, setGuestName] = useState('');
  const [phone, setPhone] = useState('');
  const [partySize, setPartySize] = useState(4);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedSlotId, setSelectedSlotId] = useState('20:00');
  const [selectedTableId, setSelectedTableId] = useState('');
  const [cart, setCart] = useState([]);
  const [allergyNotes, setAllergyNotes] = useState('');

  const notify = (type, message) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    apiRequest('/bootstrap')
      .then(data => {
        setTables(data.tables);
        setSlots(data.slots);
        setMenu(data.menu);
        setReservations(data.reservations);
        setBackendOnline(true);
      })
      .catch(err => {
        setBackendOnline(false);
        notify('error', `Backend offline (${err.message}). Start Express server on port 4000.`);
      });
  }, []);

  const isTableLocked = (tableId) => {
    const slot = slots.find(s => s.id === selectedSlotId);
    if (!slot) return false;
    return reservations.some(r => r.tableId === tableId && r.date === selectedDate && Math.abs(r.arrivalMins - slot.startMins) < 90);
  };

  const handleConfirmBooking = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        guestName,
        phone,
        partySize,
        date: selectedDate,
        slotId: selectedSlotId,
        tableId: selectedTableId,
        items: cart.map(c => ({ id: c.id, qty: c.qty })),
        allergyNotes
      };
      const res = await apiRequest('/reservations', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      setReservations(prev => [res.reservation, ...prev]);
      setCart([]);
      setSelectedTableId('');
      setAllergyNotes('');
      notify('success', `Confirmed ${res.reservation.id}! Kitchen synced.`);
    } catch (err) {
      notify('error', err.message);
    }
  };

  const handleUpdateKds = async (resId, status) => {
    try {
      const data = await apiRequest(`/reservations/${resId}/kds`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      setReservations(prev => prev.map(r => r.id === resId ? data.reservation : r));
    } catch (err) {
      notify('error', err.message);
    }
  };

  const handleCheckIn = async (resId) => {
    try {
      const data = await apiRequest(`/reservations/${resId}/checkin`, { method: 'PATCH' });
      setReservations(prev => prev.map(r => r.id === resId ? data.reservation : r));
      notify('success', 'Guest checked in — KDS ticket promoted to PRIORITY!');
    } catch (err) {
      notify('error', err.message);
    }
  };

  const kdsTickets = useMemo(() => {
    return [...reservations].map(res => {
      const maxPrep = res.items.length ? Math.max(...res.items.map(i => i.prepTime)) : 15;
      const targetPrepStart = res.arrivalMins - maxPrep;
      const minsUntilArrival = res.arrivalMins - simClockMins;
      const shouldFireNow = ((targetPrepStart - simClockMins) <= 0 && res.kdsStatus === 'Pending') || (res.checkedIn && res.kdsStatus === 'Pending');
      return { ...res, maxPrep, targetPrepStart, minsUntilArrival, shouldFireNow };
    });
  }, [reservations, simClockMins]);

  const isDarkKds = activeTab === 'kds';

  return (
    <div className={`min-h-screen ${isDarkKds ? 'bg-[#0B0F19] text-white' : 'bg-[#FAF8F5] text-stone-900'}`}>
      {toast && (
        <div className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-bold text-white ${toast.type === 'error' ? 'bg-red-600' : 'bg-emerald-600'}`}>
          {toast.message}
        </div>
      )}

      <header className={`sticky top-0 z-40 border-b ${isDarkKds ? 'bg-[#111827] border-slate-800' : 'bg-white border-stone-200'}`}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C2410C] text-white flex items-center justify-center font-bold">
              <i className="fa-solid fa-fire-burner"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold">SpiceStack v2.0</h1>
              <p className="text-xs text-stone-500">
                {backendOnline ? '● API Connected (Express + Atomic Store)' : '● Offline Mode'}
              </p>
            </div>
          </div>

          <nav className="flex gap-2">
            {['diner', 'kds', 'hostess'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3.5 py-2 rounded-lg text-sm font-semibold capitalize ${
                  activeTab === tab ? 'bg-[#C2410C] text-white' : 'text-stone-600 hover:bg-stone-100'
                }`}
              >
                {tab === 'diner' ? 'Reserve & Menu' : tab === 'kds' ? 'Kitchen KDS' : 'Hostess Floor'}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span>{formatMinsToTime(simClockMins)}</span>
            <button onClick={() => setSimClockMins(m => m + 5)} className="px-2 py-1 rounded bg-stone-200 text-stone-900 font-bold">+5m</button>
          </div>
        </div>
      </header>

      {activeTab === 'diner' && (
        <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 space-y-6">
            <section className="bg-white rounded-2xl p-6 border border-stone-200">
              <h2 className="text-xl font-bold mb-4">1. Atomic Table Reservation</h2>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="px-3 py-2 rounded-xl border" />
                <select value={partySize} onChange={e => setPartySize(Number(e.target.value))} className="px-3 py-2 rounded-xl border">
                  {[1,2,3,4,5,6].map(n => <option key={n} value={n}>{n} Guests</option>)}
                </select>
                <select value={selectedSlotId} onChange={e => setSelectedSlotId(e.target.value)} className="px-3 py-2 rounded-xl border">
                  {slots.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {tables.map(tbl => {
                  const locked = isTableLocked(tbl.id);
                  const disabled = locked || tbl.capacity < partySize;
                  return (
                    <button
                      key={tbl.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => setSelectedTableId(tbl.id)}
                      className={`p-3 rounded-xl border text-left ${
                        selectedTableId === tbl.id ? 'border-[#C2410C] bg-orange-50' : disabled ? 'opacity-50 bg-stone-100' : 'bg-white'
                      }`}
                    >
                      <div className="font-bold text-sm">{tbl.name} ({tbl.capacity}-top)</div>
                      <div className="text-xs text-stone-500">{locked ? 'Locked' : tbl.zone}</div>
                    </button>
                  );
                })}
              </div>
            </section>

            <section className="bg-white rounded-2xl p-6 border border-stone-200">
              <h2 className="text-xl font-bold mb-4">2. Pre-Order Menu</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {menu.map(item => (
                  <div key={item.id} className="p-3 rounded-xl border flex justify-between items-center">
                    <div>
                      <div className="font-bold text-sm">{item.emoji} {item.name}</div>
                      <div className="text-xs text-stone-500">₹{item.price} • {item.prepTime}m prep</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCart(prev => {
                        const ex = prev.find(i => i.id === item.id);
                        return ex ? prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i) : [...prev, { ...item, qty: 1 }];
                      })}
                      className="px-3 py-1 rounded-lg bg-stone-900 text-white text-xs font-bold"
                    >+ Add</button>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <aside className="lg:col-span-4">
            <form onSubmit={handleConfirmBooking} className="bg-white rounded-2xl p-6 border border-stone-200 space-y-4">
              <h3 className="text-lg font-bold">Booking & Sync</h3>
              <input type="text" required placeholder="Guest Name" value={guestName} onChange={e => setGuestName(e.target.value)} className="w-full px-3 py-2 rounded-xl border text-sm" />
              <input type="tel" required placeholder="+91 9876543210" value={phone} onChange={e => setPhone(e.target.value)} className="w-full px-3 py-2 rounded-xl border text-sm" />
              <input type="text" placeholder="Allergy notes" value={allergyNotes} onChange={e => setAllergyNotes(e.target.value)} className="w-full px-3 py-2 rounded-xl border text-sm" />
              <div className="text-xs text-stone-600">Items in cart: {cart.reduce((s, i) => s + i.qty, 0)}</div>
              <button type="submit" className="w-full py-3 rounded-xl bg-[#C2410C] text-white font-bold text-sm">
                Confirm & Sync Kitchen
              </button>
            </form>
          </aside>
        </main>
      )}

      {activeTab === 'kds' && (
        <KdsBoard tickets={kdsTickets} tables={tables} formatMinsToTime={formatMinsToTime} onUpdateStatus={handleUpdateKds} />
      )}

      {activeTab === 'hostess' && (
        <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {tables.map(tbl => {
            const res = reservations.find(r => r.tableId === tbl.id);
            return (
              <div key={tbl.id} className="bg-white rounded-2xl p-5 border border-stone-200 space-y-3">
                <div className="font-bold">{tbl.name} ({tbl.zone})</div>
                {res ? (
                  <>
                    <div className="text-sm">{res.guestName} • {res.slotLabel}</div>
                    {!res.checkedIn && (
                      <button onClick={() => handleCheckIn(res.id)} className="w-full py-2 rounded-xl bg-[#C2410C] text-white text-xs font-bold">
                        Guest Arrived — Check In
                      </button>
                    )}
                  </>
                ) : (
                  <div className="text-xs text-stone-400">Vacant</div>
                )}
              </div>
            );
          })}
        </main>
      )}
    </div>
  );
}
