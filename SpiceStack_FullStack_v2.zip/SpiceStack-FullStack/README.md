# SpiceStack: TableTurn Hack (Full-Stack Edition)

Arrival-synchronized restaurant table reservation, meal pre-ordering, and high-contrast Kitchen Display System (KDS).

## Architectural Improvements (Addressing Evaluation Feedback)
1. **Modular Full-Stack Architecture**: Separated into an Express REST API (`/server`) with atomic file-backed persistence and a modular React + Vite frontend (`/client`).
2. **Arrival-Synchronized KDS Engine**: `TargetPrepStart = GuestArrivalTime - MaxDishPrepTime` with hostess early-arrival override.
3. **Server-Side Input Validation & Atomic Locking**: Express middleware validates payloads (phone regex, party size bounds, menu IDs) and enforces 90-minute atomic slot locking on the server.
4. **Automated Test Suite**: Includes unit and API integration tests (`npm test` inside `/server`) covering the firing heuristic, billing math, and double-booking prevention.
5. **Resilient UI**: Global React Error Boundary, toast notifications (replacing blocking `alert()` calls), and graceful fallback if the backend is offline.

## Quick Start
```bash
# 1. Start Backend & Run Automated Tests
cd server
npm install
npm test
npm start

# 2. Start Frontend (in a second terminal)
cd client
npm install
npm run dev
```
